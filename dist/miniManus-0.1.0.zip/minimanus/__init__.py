#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
miniManus package initialization.
"""

__version__ = "0.1.0"
__author__ = "miniManus Team"
__license__ = "MIT"
